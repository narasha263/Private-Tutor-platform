<?php
session_start();


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include_once 'header.php';

$servername = "localhost";
$username = "root";
$password = "";
$database = "private tutor platform";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch and display tutor's sessions
function displaySessions() {
    global $conn;
    $tutor_id = $_SESSION['user_id'];
    $sql = "SELECT * FROM sessions WHERE tutor_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $tutor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<h4>Your Sessions</h4>";
    if ($result->num_rows > 0) {
        echo "<ul>";
        while ($row = $result->fetch_assoc()) {
            echo "<li>{$row['subject']} - {$row['date_time']} <a href='delete_session.php?id={$row['session_id']}'>Delete</a></li>";
        }
        echo "</ul>";
    } else {
        echo "<p>No sessions found.</p>";
    }

    $stmt->close();
}

// Call the function to display sessions
displaySessions();

// Form to add a new session
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $subject = $_POST['subject'];
    $date_time = $_POST['date_time'];

    // Insert the new session into the database
    $sql = "INSERT INTO sessions (tutor_id, subject, date_time) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $_SESSION['user_id'], $subject, $date_time);
    $stmt->execute();

    // Refresh the page to display the updated sessions
    header("Location: tutor_session.php");
    exit();
}
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 bg-light sidebar">
            <!-- Sidebar content -->
        </div>

        <!-- Main content area -->
        <main role="main" class="col-md-9 ml-sm-auto col-lg-9 px-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h2 class="h2">Tutor Sessions</h2>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h3>Welcome, <?php echo $_SESSION['username']; ?>!</h3>
                        <p>Here you can view and manage your tutoring sessions.</p>

                        <!-- Form to add a new session -->
                        <h4>Add New Session</h4>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div class="mb-3">
                                <label for="subject" class="form-label">Subject</label>
                                <input type="text" class="form-control" id="subject" name="subject" required>
                            </div>
                            <div class="mb-3">
                                <label for="date_time" class="form-label">Date and Time</label>
                                <input type="datetime-local" class="form-control" id="date_time" name="date_time" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Session</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include_once 'footer.php'; ?>
