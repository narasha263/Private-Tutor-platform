<?php include_once 'header.php'?>

<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection
    require_once "config.php";

    // Get username and password from form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare statement to fetch user details from the database
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ? AND role = 'tutor'");
    $stmt->bind_param("s", $username);

    // Execute the prepared statement
    $stmt->execute();

    // Bind result variables
    $stmt->bind_result($user_id, $db_username, $db_password);

    // Check if user exists
    if ($stmt->fetch()) {
        // Verify password
        if (password_verify($password, $db_password)) {
            // Password is correct, start a new session
            session_start();

            // Store user data in session variables
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $db_username;
            $_SESSION['role'] = 'tutor';

            // Redirect to dashboard or homepage
            header("Location: tutor_dashboard.php");
            exit(); // Terminate script execution after redirection
        } else {
            // Password is incorrect
            echo "Invalid password";
        }
    } else {
        // User does not exist
        echo "User not found";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
<?php include_once 'footer.php'?>
