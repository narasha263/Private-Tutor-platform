<?php
session_start();

require_once 'config.php';
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize input data
    $username = sanitize_input($_POST['username']);
    $password = sanitize_input($_POST['password']);

    // Additional fields for registration (e.g., email, name, role, etc.)
    // You may include more fields as per your requirements

    // Validate input
    if (!empty($username) && !empty($password)) {
        // Perform password hashing
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user data into database
        $conn = db_connect();
        $query = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";
        $result = mysqli_query($conn, $query);

        if ($result) {
            // Redirect to login page or dashboard after successful registration
            header("Location: login.php");
            exit();
        } else {
            $error_message = "Registration failed. Please try again.";
        }
    } else {
        $error_message = "Please enter both username and password.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body>
    <h2>Register</h2>
    <?php if (isset($error_message)) echo "<p>$error_message</p>"; ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br>
        <!-- Additional fields for registration -->
        <button type="submit">Register</button>
    </form>
</body>
</html>
