<?php
session_start();

require_once 'config.php';
?>
<?php include_once 'header.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Private Tutor Platform</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
body {
    font-family: Arial, sans-serif;
    background-color: black;
}

.login-container {
    max-width: 400px;
    margin: 100px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

.login-form h2 {
    margin-bottom: 20px;
    text-align: center;
    color: navy;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
    color: #555;
}

.form-group input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.btn {
    display: block;
    width: 100%;
    padding: 10px;
    text-align: center;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.btn:hover {
    background-color: #0056b3;
}

.register-option {
    text-align: center;
}

.register-option p {
    margin-bottom: 10px;
    color: #555;
}

.register-option a {
    color: #007bff;
    text-decoration: none;
    transition: color 0.3s;
}

.register-option a:hover {
    color: #0056b3;
}
  </style>
</head>
<body>

<!-- Navigation Section -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!-- Your existing navigation code here -->
</nav>

<!-- Banner Section -->
<section id="banner">
  <!-- Your existing banner content here -->
</section>

<!-- Login Forms -->
<section id="login" class="py-5">
  <div class="container">
    <div class="row justify-content-center">
      <!-- Tutor Login Form -->
      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <h2 class="text-center mb-4">Tutor Login</h2>
            <form action="tutor_login_process.php" method="post">
              <div class="mb-3">
                <label for="tutor-username" class="form-label">Username/Email:</label>
                <input type="text" class="form-control" id="tutor-username" name="username" required>
              </div>
              <div class="mb-3">
                <label for="tutor-password" class="form-label">Password:</label>
                <input type="password" class="form-control" id="tutor-password" name="password" required>
              </div>
              <button type="submit" class="btn btn-primary btn-lg btn-block">Login</button>
            </form>
            <p class="text-center mt-3">New tutor? <a href="tutor_register.php">Register here</a></p>

          </div>
        </div>
      </div>
      <!-- Student Login Form -->
      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <h2 class="text-center mb-4">Student Login</h2>
            <form action="student_login_process.php" method="post">
              <div class="mb-3">
                <label for="student-username" class="form-label">Username/Email:</label>
                <input type="text" class="form-control" id="student-username" name="username" required>
              </div>
              <div class="mb-3">
                <label for="student-password" class="form-label">Password:</label>
                <input type="password" class="form-control" id="student-password" name="password" required>
              </div>
              <button type="submit" class="btn btn-primary btn-lg btn-block">Login</button>
            </form>
            <p class="text-center mt-3">New student? <a href="student_register.php">Register here</a></p>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include_once 'footer.php'?>
<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
