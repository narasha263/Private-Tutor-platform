<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Private Tutor Platform</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: black;
      color: white;
      background-image: url('images/bg.jpg'); /* Fix typo */
    }
    #banner{
        color:red;
     
    }
    #services{
        color:black;

    }
    .card-text{
        color:black;
        font: Arial, sans-serif;
    }
    .logo img {
  max-width: 100px; 
  max-height: 80px; 
}

  </style>
</head>
<body>

<!-- Navigation Section -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
        <div class="logo">
      <img src="logo.jpg" alt="Your Platform Logo">
    </div>
    <a class="navbar-brand" href="#">Tutor Platform</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="aboutus.php">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="services.php">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="tutor.php">Tutors</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact.php">Contact Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.php">Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Banner Section -->
<section id="banner">
  <div class="container text-center py-5">
  <img src="bg.jpg" alt="Your Platform Logo">
    
    <h1>Welcome to Private Tutor Platform</h1>
    <p class="lead">Find experienced tutors for personalized learning.</p>
    <a href="tutor.php" class="btn btn-primary btn-lg">Find a Tutor</a>
  </div>
</section>


<!-- Services Section -->
<section id="services" class="bg-light py-5">
  <div class="container">
    <h2 class="text-center mb-4">Our Services</h2>
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">One-on-One Tutoring</h5>
            <p class="card-text">Get personalized attention from experienced tutors tailored to your learning needs.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Group Sessions</h5>
            <p class="card-text">Join group sessions to learn collaboratively with peers and share knowledge.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Exam Preparation</h5>
            <p class="card-text">Prepare for exams with specialized tutoring programs designed to boost your confidence and performance.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Testimonials Section -->
<section id="testimonials" class="py-5">
  <div class="container">
    <h2 class="text-center mb-4">What Our Students Say</h2>
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <p class="card-text">"I found an amazing tutor through this platform who helped me improve my grades significantly."</p>
            <p class="text-end"><em>- John Mfalme</em></p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <p class="card-text">"The tutors here are highly knowledgeable and dedicated. I'm very satisfied with my learning experience."</p>
            <p class="text-end"><em>- Jane Wangare</em></p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <p class="card-text">"I struggled with math until I found a tutor who explained concepts in a way that finally made sense to me. Highly recommended!"</p>
            <p class="text-end"><em>- Emily Njoki</em></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Call to Action Section -->
<section id="cta" class="bg-primary text-white py-5">
  <div class="container text-center">
    <h2 class="mb-4">Start Your Learning Journey Today</h2>
    <p class="mb-4">Find the perfect tutor to help you achieve your academic goals.</p>
    <a href="#" class="btn btn-light btn-lg">Find a Tutor</a>
  </div>
</section>

<!-- Footer Section -->
<footer class="bg-dark text-white py-4">
  <div class="container text-center">
    <p>&copy; <?php echo date('Y'); ?> Private Tutor Platform. All rights reserved.</p>
  </div>
</footer>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
