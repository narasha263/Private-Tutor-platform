<?php include_once 'header.php'?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Private Tutor Platform - Tutors</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>

.tutor-image {
  max-width: 200px; 
}
body {
      background: black;
      color: white;
      background-image: url('images/bg.jpg'); /* Fix typo */}
  </style>
</head>
<body>


<!-- Banner Section -->
<section id="banner">
  <div class="container text-center py-5">
    <h1>Explore Our Tutors</h1>
    <p class="lead">Find experienced tutors for personalized learning.</p>
  </div>
</section>

<!-- Tutors Section -->
<section id="tutors" class="py-5">
  <div class="container">
    <div class="row">
      <!-- Example tutor card -->
      <div class="col-md-4">
        <div class="card">
          <img src="tutor1.jpg" class="card-img-top tutor-image" alt="Tutor Image">
          <div class="card-body">
            <h5 class="card-title">Sarah</h5>
            <p class="card-text">Subject: Mathematics<br>Experience: 5 years</p>
            <a href="profile.php?tutor=1" class="btn btn-primary">View Profile</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="tutor2.jpg" class="card-img-top tutor-image" alt="Tutor Image">
          <div class="card-body">
            <h5 class="card-title">John</h5>
            <p class="card-text">Subject: Physics<br>Experience: 7 years</p>
            <a href="profile.php?tutor=2" class="btn btn-primary">View Profile</a>
          </div>
        </div>
      </div>
      <!-- Tutor card 3 -->
      <div class="col-md-4">
        <div class="card">
          <img src="tutor3.jpg" class="card-img-top tutor-image" alt="Tutor Image">
          <div class="card-body">
            <h5 class="card-title">Emily</h5>
            <p class="card-text">Subject: Chemistry<br>Experience: 4 years</p>
            <a href="profile.php?tutor=3" class="btn btn-primary">View Profile</a>
          </div>
        </div>
      </div>    </div>
  </div>
</section>
    

<!-- Footer Section -->
<footer class="bg-dark text-white py-4">
  <div class="container text-center">
    <p>&copy; <?php echo date('Y'); ?> Private Tutor Platform. All rights reserved.</p>
  </div>
</footer>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
