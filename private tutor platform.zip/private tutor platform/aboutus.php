<?php include_once 'header.php'?>

<!-- About Us Section -->
<section id="about" class="py-5">
  <div class="container">
    <h2 class="text-center mb-4">About Us</h2>
    <div class="row">
      <div class="col-lg-6">
        <h3>Who We Are</h3>
        <p>We are a leading private tutor platform dedicated to connecting students with qualified tutors across various subjects and levels.</p>
      </div>
      <div class="col-lg-6">
        <h3>Why Choose Us</h3>
        <ul>
          <li>Personalized learning experience</li>
          <li>Wide range of subjects and levels</li>
          <li>Flexible scheduling</li>
          <li>Experienced and vetted tutors</li>
        </ul>
      </div>
    </div>
  </div>
</section>
<?php include_once 'footer.php'?>